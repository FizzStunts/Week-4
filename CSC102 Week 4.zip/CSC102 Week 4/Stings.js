// globable variables
var count = 0;
var interValid = 0;
let change = -200;
// main function for the program
function palChecker()
{
    // variable for the submitted text
    var word1 = document.getElementById("palWord").value;
    // variable used in the "for" loop
    var i;
    // variable for the reversed version 
    var reversed = "";
    
    for (i= word1.length-1; i >=0; i--)
    {
        // sets the reversed version of the submitted text
        reversed += word1[i];
        // displays if the word is a palindrome and gives the score
        if (word1 == reversed)
        {
            document.getElementById("answer").innerHTML = "Palindrome Detected! Want to keep going";
            count++;
            document.getElementById("score").innerHTML = "Score: " + count;
        }
        // displays if the word isn't a palindrome
        else
        {
            document.getElementById("answer").innerHTML = "Not a Palindrome try again";
        }
    }
}
// this is to validate the login
function loginVar()
{
    // variables for the first and last name as well zip code
    var FstName = document.getElementById("fName").value;
    var SndName = document.getElementById("lName").value;
    var zipC = document.getElementById("zipCode").value;
    // puts the first and last name together
    var fulName = FstName + " " + SndName;
    // varifies loging
    if ((fulName == "Taren Vivlemore") || (fulName == "Jill Coddington"))
    {
        if ((zipC == "98638") || (zipC == "85283"))
        {
            // sends to the hidden reward page
            location.replace("Hidden Meme.html");
        }
        else
        {
            // sends to the hidden wrong info page
            location.replace("Wrong Meme.html");
        }
    }
    else if ((fulName != "Taren Vivlemore") || (fulName != "Jill Coddington"))
    {
        // sends to the hidden wrong info page
        location.replace("Wrong Meme.html");
    }
}
// this will return to the main page
function goBack()
{
    location.replace("Strings.html");
}
// starts sound and moving image
function partyTime()
{
    //sets the sound i want to play
    mySound = new sound("crowd-cheer-ii-6263.mp3");
    //plays the sound
    mySound.play();
    //length of time i want my image to move
    var currTime = 230;
    //sets the image i want to move
    var image = document.getElementById("running");
    //moves my image based on change
    interValid = setInterval(function() {
        image.style.left = change + "px";
    },30)
    //timer loop set to make my image reset
    for (var i=0;i<1000;i++)
    {
        setTimeout(function () {
            currTime = currTime -1;
            if (currTime == 10)
            {
                change = -200;
                currTime = 230;
                i = 0;
            }
            else
            {
                change += 10;
            }
        },100*i);
    }
    //disables start button and enables stop button
    document.getElementById("quiteT").disabled = false;
    document.getElementById("partyT").disabled = true;
}
//Helper function !!DO NOT TOUCH!!
function sound(src)
{
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.play = function()
    {
        this.sound.play()
    }
}
//stop function
function quiteTime()
{
    //reloads the page
    window.location.reload();
}